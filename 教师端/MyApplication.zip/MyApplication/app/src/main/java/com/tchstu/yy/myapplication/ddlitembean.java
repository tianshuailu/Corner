package com.tchstu.yy.myapplication;

public class ddlitembean {
    public String ddlseq;
    public String ddltxt;
    public ddlitembean(String ddlseq,String ddltxt){
        this.ddlseq = ddlseq;
        this.ddltxt = ddltxt;
    }
}
