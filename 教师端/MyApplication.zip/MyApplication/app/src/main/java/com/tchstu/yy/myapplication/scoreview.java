package com.tchstu.yy.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class scoreview extends Activity {
    private ListView listview;
    private EditText courseedit;
    private Activity act = new Activity();

    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scoreview);


    }



    public List<Map<String, Object>> putData() throws JSONException,InterruptedException {
             courseedit = (EditText)findViewById(R.id.score_view) ;
            JSONObject jsobj = new JSONObject();
            jsobj.put("course",courseedit.getText().toString());
            JsonConnect jsc = new JsonConnect();
            JSONArray jsarray = new JSONArray(jsc.getData(jsobj,"score_view"));
            List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
            for(int i=0;i<jsarray.length();i++){
                Map<String,Object> map = new HashMap<>();
                System.out.println(jsarray.getJSONObject(i).get("cname"));
                map.put("name",jsarray.getJSONObject(i).get("cname"));
                map.put("course",jsarray.getJSONObject(i).get("sname"));
                map.put("score",jsarray.getJSONObject(i).get("grade").toString());
                list.add(map);
            }
            /*Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("studentID", "1163710205");
            map1.put("Name", "张三");
            map1.put("score", "88");
            Map<String, Object> map2 = new HashMap<String, Object>();
            map2.put("studentID", "1163710206");
            map2.put("Name", "张四");
            map2.put("score", "88");
            Map<String, Object> map3 = new HashMap<String, Object>();
            map3.put("studentID", "1163710207");
            map3.put("Name", "张无");
            map3.put("score", "80");
            list.add(map1);
            list.add(map2);
            list.add(map3);*/
            return list;
        }
    public void onsearch(View view) throws InterruptedException{
            listview = (ListView) findViewById(R.id.score_list);
            try{
                MyAdapter2 myAdapter = new MyAdapter2(listview.getContext(), putData());
                System.out.println(putData());
                listview.setAdapter(myAdapter);
            }
            catch (JSONException e){
            }
    }
    public void onfix(View view){
        Intent intent = new Intent(this,score_tch_sub.class);
        startActivity(intent);
    }
    public void onexit(View view){
        Intent intent = new Intent(this,MainActivity.class);
    }

}
