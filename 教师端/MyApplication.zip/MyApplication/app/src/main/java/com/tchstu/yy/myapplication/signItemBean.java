package com.tchstu.yy.myapplication;

public class signItemBean {
    public String stuname;
    public String id;
    public signItemBean(String stuname, String id){
        stuname = this.stuname;
        id = this.id;
    }
}

