package com.tchstu.yy.myapplication;

public class ddl {
    private String ddltxt;
    //ddl arrray
    public static final ddl[] studdl = {};

    private ddl(String ddltxt){
        this.ddltxt = ddltxt;
    }
    public String getDdltxt(){
        return ddltxt;
    }

}
