package com.tchstu.yy.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;



public class ddl_tch  extends Activity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ddl_teacher);
         TimePicker timepickerx = (TimePicker) findViewById(R.id.ddl_timepicker);
        timepickerx.setIs24HourView(true);
        }



    public void onsendddl(View view) throws JSONException,InterruptedException {
        DatePicker datepicker;
        TimePicker timepicker;
        EditText ddltchedit;
        EditText ddltchcrs;
        String flag,jsc;
        ddltchcrs = (EditText)findViewById(R.id.ddl_tch_course);
        ddltchedit = (EditText) findViewById(R.id.ddl_tch_contxt);
        datepicker = (DatePicker) findViewById(R.id.ddl_datepicker);
        timepicker = (TimePicker) findViewById(R.id.ddl_timepicker);
        StringBuilder ddline1 = new StringBuilder();
        //StringBuilder ddline2 = new StringBuilder();
        //ddline1.append(datepicker.getYear());
        ddline1.append(datepicker.getMonth()+1);
        ddline1.append("-");
        ddline1.append(datepicker.getDayOfMonth());
        ddline1.append("   ");
        ddline1.append(timepicker.getCurrentHour());
        ddline1.append(":");
        ddline1.append(timepicker.getCurrentMinute());
        JSONObject jsobj = new JSONObject();
        jsobj.put("cname",ddltchcrs.getText().toString());
        jsobj.put("hname",ddltchedit.getText().toString());
        jsobj.put("finish",ddline1.toString());
        JsonConnect jc = new JsonConnect();
        jsc = jc.getData(jsobj, "ddl_tch_sub");
        flag = new JSONObject(jsc).get("status").toString();
        if(flag == "1"){
        Toast.makeText(ddl_tch.this, "submit success", Toast.LENGTH_SHORT);}
    }

}
