package com.tchstu.yy.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class ddladapter extends BaseAdapter {
    private List<ddlitembean> mList;
    private LayoutInflater mInflater;

    public ddladapter(Context context, List<ddlitembean> list){
        mList = list;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount(){
        return mList.size();
    }

    @Override
    public Object getItem(int position){
        return mList.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if (convertView == null){
            convertView = mInflater.inflate(R.layout.ddlitem, null);
        }
        TextView ddlseg;
        return convertView;
    }
}
