package com.tchstu.yy.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;
import java.util.Map;

public class signAdapter extends BaseAdapter {
    private List<Map<String,Object>> mList;
    private LayoutInflater mInflater;

    public signAdapter( Context context, List<Map<String,Object>> list){
        mList = list;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount(){
        return mList.size();
    }

    @Override
    public Object getItem(int position){
        return mList.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertview, ViewGroup paraent){
        signAdapter.ViewHolder holder1 = null;
        if(convertview == null){
            holder1 = new ViewHolder();
            convertview = mInflater.inflate(R.layout.signitem,null);
            holder1.stuname = (TextView)convertview.findViewById(R.id.signlist_stuname);
            holder1.id = (TextView)convertview.findViewById(R.id.signlist_id);
            convertview.setTag(holder1);
        }else {
            holder1 = (signAdapter.ViewHolder) convertview.getTag();
        }


        holder1.stuname.setText((String)mList.get(position).get("name"));
        holder1.id.setText((String)mList.get(position).get("id"));

        return convertview;

    }
    public final class ViewHolder{

        public TextView stuname;
        public TextView id;

    }






}

