package com.tchstu.yy.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;



public class score_tch_sub extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scorefixiing);
    }
    public void scoreonsub(View view) throws JSONException,InterruptedException {
        EditText name;
        EditText course;
        EditText score;
        name = (EditText)findViewById(R.id.score_name);
        course = (EditText)findViewById(R.id.score_course);
        score = (EditText)findViewById(R.id.score_score);
        JSONObject jsobj = new JSONObject();
        jsobj.put("sid",name.getText().toString());
        jsobj.put("cid",course.getText().toString());
        jsobj.put("grade",score.getText().toString());
        JsonConnect jsc = new JsonConnect();
        String flag = new JSONObject(jsc.getData(jsobj,"score_fix")).get("status").toString();
        if(flag == "1")
            Toast.makeText(score_tch_sub.this,"success",Toast.LENGTH_SHORT);
        else
            Toast.makeText(score_tch_sub.this,"fail",Toast.LENGTH_SHORT);

    }
}
