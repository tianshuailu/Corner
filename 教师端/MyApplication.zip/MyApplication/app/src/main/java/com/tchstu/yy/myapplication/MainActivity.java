package com.tchstu.yy.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tch_client);
    }
    public void totchsign(View view){
        Intent intent = new Intent(this,sign_tch_sub.class);
        startActivity(intent);
    }
    public void totchddl(View view){
        Intent intent = new Intent(this,ddl_tch.class);
        startActivity(intent);
    }
    public void totchscore(View view){
        Intent intent = new Intent(this,scoreview.class);
        startActivity(intent);
    }
}
