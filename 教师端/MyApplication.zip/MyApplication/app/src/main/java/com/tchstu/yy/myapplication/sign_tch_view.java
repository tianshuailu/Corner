package com.tchstu.yy.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class sign_tch_view extends Activity {
public static final String EXTRA_MESSAGE = "password";
ListView signlistview;
String jsstring;
EditText course;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_tch_view);
        Intent intent = getIntent();
        String tchpass = intent.getStringExtra(EXTRA_MESSAGE);
        TextView tch_pass = (TextView)findViewById(R.id.tch_get_password);
        tch_pass.setText(tchpass);

    }

    public List<Map<String, Object>> putData() throws JSONException,InterruptedException {
        course = findViewById(R.id.sign_tch_view_course);
        List<Map<String,Object>> signitemlist = new ArrayList<>();
        JSONObject jsobj = new JSONObject();
        jsobj.put("course",course.getText().toString());
        JsonConnect jsc = new JsonConnect();
        jsstring = jsc.getData(jsobj, "sign_tch_view");
        JSONArray jsarray = new JSONArray(jsstring);

        for(int i=0;i <jsarray.length();i++){
            Map<String,Object> map = new HashMap<>();
            map.put("name",jsarray.getJSONObject(i).get("name"));
            map.put("id",jsarray.getJSONObject(i).get("id").toString());
            signitemlist.add(map);
        }
        return signitemlist;
    }

    public void getStudent(View view) throws JSONException,InterruptedException{


        signlistview = findViewById(R.id.list_stu_sign);
        signlistview.setAdapter(new signAdapter(this, putData()));
    }
}
