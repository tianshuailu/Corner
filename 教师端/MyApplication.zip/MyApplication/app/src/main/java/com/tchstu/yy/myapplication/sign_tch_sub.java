package com.tchstu.yy.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;



public class sign_tch_sub extends Activity {
    Button signtchputin;
    EditText putinedit;
    EditText courseEdit;
    String signpass;
    String course;
    String flag;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_tch_sub);
        signtchputin = (Button)findViewById(R.id.sign_tch_putin_sub);

    }

    public void tchPutinsub(View view) throws JSONException,InterruptedException {
        putinedit = (EditText)findViewById(R.id.tch_putin_edit) ;
        courseEdit = (EditText)findViewById(R.id.tch_putin_course);
        signpass = putinedit.getText().toString();
        course = courseEdit.getText().toString();
        JSONObject jsobj = new JSONObject();
        jsobj.put("userid",course);
        jsobj.put("pin",signpass);
        JsonConnect jsc = new JsonConnect();
        flag = jsc.getData(jsobj, "sign_tch_sub");
        Intent intent = new Intent(this, sign_tch_view.class);
        intent.putExtra(sign_tch_view.EXTRA_MESSAGE, signpass);
        startActivity(intent);
    }
}
